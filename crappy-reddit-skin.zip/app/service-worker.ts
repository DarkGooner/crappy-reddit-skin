/// <reference lib="webworker" />

// This service worker can be customized
export default null

export const config = {
  runtime: "nodejs", //mine
}

